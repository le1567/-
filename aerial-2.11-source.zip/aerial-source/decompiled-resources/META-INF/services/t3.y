u3.b

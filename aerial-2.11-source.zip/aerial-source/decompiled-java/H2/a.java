package H2;

/* compiled from: r8-map-id-133b242b092d1a7804ddbbfea89ec2448dabf6a5e0d97a31abd57b171a3f8e87 */
/* loaded from: classes.dex */
public abstract class a implements f {
    public abstract boolean a(char c4);

    @Override // H2.f
    public final boolean apply(Object obj) {
        return a(((Character) obj).charValue());
    }
}

package T;

import a.AbstractC0328a;

/* compiled from: r8-map-id-133b242b092d1a7804ddbbfea89ec2448dabf6a5e0d97a31abd57b171a3f8e87 */
/* loaded from: classes.dex */
public final class K implements O {
    @Override // T.O
    public final L a(long j4, F0.l lVar, F0.c cVar) {
        return new F(AbstractC0328a.b(0L, j4));
    }

    public final String toString() {
        return "RectangleShape";
    }
}

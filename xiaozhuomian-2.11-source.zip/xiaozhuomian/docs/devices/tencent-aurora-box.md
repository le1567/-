# 腾讯极光盒子

来自用户反馈，维护者手上没有。

| 机型 | 系统 / 平台 | 结果 | 来源 |
|---|---|---|---|
| 极光盒子 6 / Q5043（创维数字代工，cupid-p2，全志） | Android 10 | 开机直达和主页键都正常（守护接管，主页键后约 4 秒回 Aerial）。任何 `settings` 子命令都会让 adbd 卡住 120 秒，`pm`、`appops`、`dumpsys` 正常；Aerial 拿到 `WRITE_SECURE_SETTINGS` 后自己打开了守护，所以不需要手写设置。HOME 候选只认平台签名的桌面（极光、小湃），Aerial 进不了候选，`role add-role-holder` 不报错但无效 | #367 |
| 极光盒子 6SE、7S（BA101，Amlogic s7d） | Android 14 | 原桌面 `com.ktcp.launcher`，真正显示的是 `LauncherHomeSingleTaskActivity`（1.35 起守护认得它）。7S 上 1.36 仍然开机停在原桌面，原因还没查到，需要开机后的 `AerialGuard` 日志 | #269、#270 |

## 极光盒子 4 Pro（A4111，小湃科技，Amlogic SC2，Android 11，#928 #930）

报告人 Agent 实测（1.69 / 1.70）：原桌面 `com.ktcp.launcher`（平台签名，uid 1000），来到前台时**不发任何窗口事件**：开机约 6 秒静默盖住 Aerial、睡眠时固件自己拉起它、按主页键后 1.5 秒内守护零事件，只能靠用量统计。按键过滤开着时主页键仍由系统（uid 0）处理。无人干预时重启和待机唤醒都一直停在原桌面。

1.71 起：原桌面有 `com.ktcp.launcher` 时守护每秒查用量统计（同海信聚好看）；唤醒后的接管也查「Aerial 被原桌面静默盖住」。没有真机验证。机身插北通手柄接收器时守护在别的 App 里不过滤按键（#774 的设计），与本问题无关。

## 极光盒子 5S（创维 A4141，Amlogic，安卓 9，#1463，报告人 Agent 实测 1.93）

开机和主页键都进 Aerial（守护接管）。固件对第三方桌面打印 `block home apk`，`set-home-activity` 报 `User no Permission`，没有 `cmd role`。`/system/bin/settings` 权限是 `rwxr-x--- root system`，shell 执行不了（报 `error: closed` 或 Permission denied），读设置用 `content query --uri content://settings/secure/<名字>`，写交给 Aerial 的 CONFIG 广播。只有 USB 调试，要先插线 `adb tcpip 5555`，之后 `keep_adb` 能保住。长按主页键调不出后台，原因待查。

## 极光盒子 3mini（创维 A4101，faraday，安卓 9，1 GB，#1496，报告人 Agent 实测）

开机和在 Aerial 里按主页键正常；打开任何别的 App 后，固件马上强停 Aerial（`ActivityManager: app not allow running background: app.orchard.tv ... otherProcess has fg act: false`，`Force stopping app.orchard.tv`），守护随进程消失，计划的重启（70 秒）也没拉起来，按主页键落到 `com.ktcp.launcher`。`set-home-activity` 报 `cannot be home on user 0`（`block home apk`），设置里没有自启动 / 后台白名单。`filterHomeAlways` 无效（不是按主页键才杀）。固件规则，App 改不了。

## 极光 5S / 创维 A4141（Amlogic newton，#1463）：最近任务

守护能认出长按主页键，但 `GLOBAL_ACTION_RECENTS` 在这台是空的；最近任务是创维自己的 `com.skyworthdigital.recentsmanager/.RecentTaskActivity`（报告人 `am start -n` 能打开，`KEYCODE_APP_SWITCH` 没反应）。1.97 起导出且不要权限时就打开它，我们没实测。

## 极光盒子 7（BA102，Amlogic s7d，安卓 14，#1597 #1614）

- 固件 `block home apk`，Aerial 进不了 HOME 候选，`set-home-activity` / `role` 都失败，主页键靠守护，会先闪约 1 秒固件桌面（`com.xiaopaitech.wallpaperlauncher`）。`filterHomeAlways` 无效。报告人停用两个固件桌面加 `com.android.provision` 后开机卡在开机画面，不要这样做。
- 系统设置是创维数字的 `com.skyworthdigital.settings`（主界面 `.activity.MainActivity`、有线网络 `.activity.EthernetSettingActivity`），`ACTION_SETTINGS` 却答 AOSP 的 TV Settings（没有有线网络页）。2026-11-18 起控制中心「设置」优先打开前者，有线连接时「网络」打开以太网页（只在导出时），没有真机验证。
- 没有 HDMI 输入（`TvInputManager` 为空）；开 CEC 音量后控制中心音量条显示「由音响控制」拖不动。这两条的隐藏开关是功能建议。


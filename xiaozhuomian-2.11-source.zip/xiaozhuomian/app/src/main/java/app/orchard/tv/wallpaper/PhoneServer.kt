package app.orchard.tv.wallpaper

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.core.content.getSystemService
import app.orchard.tv.apps.AppCatalog
import app.orchard.tv.apps.FOLDER_KEY_PREFIX
import app.orchard.tv.apps.AppEntry
import app.orchard.tv.apps.AppNames
import app.orchard.tv.apps.CustomIcons
import app.orchard.tv.apps.IconLibrary
import app.orchard.tv.apps.SourceDevice
import app.orchard.tv.apps.SourceLooks
import app.orchard.tv.apps.TileArtFactory
import app.orchard.tv.settings.AerialSettings
import app.orchard.tv.settings.KidsLock
import app.orchard.tv.settings.Restricted
import app.orchard.tv.settings.RestrictedKind
import app.orchard.tv.settings.RestrictedRules
import app.orchard.tv.guard.HomeGuardService
import app.orchard.tv.guard.KidsWatch
import android.os.SystemClock
import app.orchard.tv.system.Diagnostics
import app.orchard.tv.system.currentNetwork
import app.orchard.tv.settings.FocusStyle
import app.orchard.tv.weather.Weather
import androidx.core.graphics.createBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.Inet4Address
import java.security.SecureRandom

/**
 * The page a phone opens after scanning the TV's QR code: choose a wallpaper and the screensaver,
 * send photos, give an app's tile a picture of one's own, and name the weather's city. Choosing
 * pictures or typing a place with a remote is slow; with a phone it is not.
 *
 * It listens on the local network while Aerial runs (see [listen]), and every address carries a
 * random token shown only on the TV (the QR code and the address under it), so another device on
 * the network cannot use it by guessing. The token stays the same from one start to the next.
 */
class PhoneServer private constructor(private val context: Context, private val token: String) : NanoHTTPD(PORT) {

    override fun serve(session: IHTTPSession): Response {
        val prefix = "/$token"
        val uri = session.uri
        if (!uri.startsWith(prefix)) return text(Response.Status.NOT_FOUND, "Not found")
        val path = uri.removePrefix(prefix).ifEmpty { "/" }
        return runCatching {
            // In Kids and Elders mode the page changes nothing without the parental PIN: anyone on
            // the network with the address (a child with a phone) could otherwise undo the mode.
            // The page sends it with each change once it is entered (header X-Aerial-Pin).
            if (session.method == Method.POST && path != "/api/kids/unlock" && (Restricted.active || path.startsWith("/api/kids/")) &&
                path != "/api/kids/start" && !pinOk(session.headers["x-aerial-pin"])
            ) return json(state().put("saved", false).put("kidsLocked", true))
            when {
                path == "/" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", page())
                session.method == Method.POST && path == "/api/kids/unlock" -> {
                    val ok = pinOk(form(session)["pin"])
                    json(state().put("saved", ok).put("pinRight", ok))
                }
                session.method == Method.POST && path == "/api/kids/allow" -> {
                    val minutes = form(session)["minutes"]?.toIntOrNull()
                    onMain { Restricted.allow(minutes?.takeIf { it > 0 }); KidsWatch.poke() }
                    json(state().put("saved", true))
                }
                session.method == Method.POST && path == "/api/kids/config" -> kidsConfig(form(session))
                session.method == Method.POST && path == "/api/kids/leave" -> {
                    onMain { Restricted.suspend(); KidsWatch.poke() }
                    json(state().put("saved", true))
                }
                session.method == Method.POST && path == "/api/kids/start" -> {
                    val can = Restricted.enabled && Restricted.allowed.isNotEmpty()
                    if (can) onMain { Restricted.start(); KidsWatch.poke() }
                    json(state().put("saved", can))
                }
                path == "/api/state" -> json(state())
                path == "/api/diagnostics" -> text(Response.Status.OK, Diagnostics.report(context))
                path.startsWith("/thumb/") -> thumb(path.removePrefix("/thumb/"))
                session.method == Method.POST && path == "/api/wallpaper" -> {
                    val id = form(session)["id"].orEmpty()
                    onMain { Wallpapers.select(id) }
                    json(state())
                }
                session.method == Method.POST && path == "/api/screensaver" -> {
                    val mode = ScreensaverMode.of(form(session)["mode"])
                    onMain { Wallpapers.chooseScreensaver(mode) }
                    json(state())
                }
                session.method == Method.POST && path == "/api/setting" -> {
                    // The few on/off settings the phone page shows, as Personalize does.
                    val f = form(session)
                    val on = f["on"] == "1"
                    val known = when (f["key"]) {
                        "wallpaperAlwaysMoves" -> { onMain { AerialSettings.chooseWallpaperAlwaysMoves(on) }; true }
                        "showWeather" -> { onMain { AerialSettings.chooseShowWeather(on) }; true }
                        "screensaverClock" -> { onMain { AerialSettings.chooseScreensaverClock(on) }; true }
                        "screensaverCaption" -> { onMain { AerialSettings.chooseScreensaverCaption(on) }; true }
                        else -> false
                    }
                    json(state().put("saved", known))
                }
                session.method == Method.POST && path == "/api/focus" -> {
                    val style = FocusStyle.of(form(session)["style"])
                    onMain { AerialSettings.chooseFocusStyle(style) }
                    json(state())
                }
                session.method == Method.POST && path == "/api/delete" -> {
                    val id = form(session)["id"].orEmpty()
                    onMain { Wallpapers.deletePhoto(id) }
                    json(state())
                }
                session.method == Method.POST && path == "/api/upload" -> upload(session)
                session.method == Method.POST && path == "/api/videos/send" -> video(session)
                session.method == Method.POST && path == "/api/videos/delete" -> {
                    val removed = ScreensaverVideos.delete(context, form(session)["id"].orEmpty())
                    if (removed) onMain { Wallpapers.videosChanged() }
                    json(state().put("removed", removed))
                }
                path.startsWith("/tile/") -> tile(java.net.URLDecoder.decode(path.removePrefix("/tile/"), "UTF-8"), own = session.parameters["art"]?.firstOrNull() == "own")
                path.startsWith("/library/") -> libraryPicture(java.net.URLDecoder.decode(path.removePrefix("/library/"), "UTF-8"), session.parameters["c"]?.firstOrNull())
                session.method == Method.POST && path == "/api/icon" -> icon(session)
                session.method == Method.POST && path == "/api/source/name" -> {
                    val f = form(session)
                    val source = AppCatalog.pinnedSources.firstOrNull { it.key == f["app"] }?.source
                    // On the main thread before answering, so the state sent back has the new name.
                    if (source != null) runBlocking(Dispatchers.Main) { SourceLooks.rename(source.id, f["name"]) }
                    json(state())
                }
                session.method == Method.POST && path == "/api/app/name" -> {
                    val f = form(session)
                    val key = f["app"].orEmpty()
                    val source = AppCatalog.pinnedSources.firstOrNull { it.key == key }?.source
                    // On the main thread before answering, so the state sent back has the new name.
                    val saved = when {
                        source != null -> { runBlocking(Dispatchers.Main) { SourceLooks.rename(source.id, f["name"]) }; true }
                        AppCatalog.loaded.any { it.key == key } -> { runBlocking(Dispatchers.Main) { AppNames.rename(key, f["name"]) }; true }
                        else -> false
                    }
                    json(state().put("saved", saved))
                }
                session.method == Method.POST && path == "/api/layout" -> layout(form(session))
                session.method == Method.POST && path == "/api/source/device" -> {
                    val f = form(session)
                    val source = AppCatalog.pinnedSources.firstOrNull { it.key == f["app"] }?.source
                    // As from the tile's menu: a device names the tile after it, "" goes back to the plain input.
                    if (source != null) runBlocking(Dispatchers.Main) { SourceLooks.chooseDevice(source.id, SourceDevice.of(f["device"])) }
                    json(state().put("saved", source != null))
                }
                session.method == Method.POST && path == "/api/source/pin" -> {
                    val f = form(session)
                    val id = f["id"].orEmpty()
                    val pin = AppCatalog.pinSource
                    val known = AppCatalog.sources.any { it.id == id }
                    if (known && pin != null) runBlocking(Dispatchers.Main) { pin(id, f["pinned"] == "1") }
                    json(state().put("saved", known && pin != null))
                }
                session.method == Method.POST && path == "/api/folder/name" -> {
                    val f = form(session)
                    val id = f["id"].orEmpty()
                    val name = f["name"].orEmpty().trim().take(FOLDER_NAME_MAX)
                    val rename = AppCatalog.renameFolder
                    val known = AppCatalog.folders.any { it.folder?.id == id }
                    // On the main thread before answering, so the state sent back has the new name.
                    if (known && name.isNotEmpty() && rename != null) runBlocking(Dispatchers.Main) { rename(id, name) }
                    json(state().put("saved", known && name.isNotEmpty() && rename != null))
                }
                session.method == Method.POST && path == "/api/icon/pick" -> {
                    // One of the library's pictures or the app's own art for one app; either
                    // replaces a picture sent from the phone.
                    val f = form(session)
                    val pkg = f["app"].orEmpty()
                    val pick = when (f["pick"]) {
                        "library" -> IconLibrary.Pick.Library
                        "own" -> IconLibrary.Pick.Own
                        else -> null
                    }
                    val choice = f["choice"]?.takeIf { it.isNotEmpty() }
                    val ok = installed(pkg) && pick != null && (pick != IconLibrary.Pick.Library ||
                        IconLibrary.choices(pkg).any { choice == null || it.id == choice })
                    if (ok) {
                        CustomIcons.clear(pkg)
                        // Kept even for the library, which most apps use anyway: a firmware app
                        // drawn as Aerial's own tile takes it only when picked.
                        IconLibrary.choose(pkg, pick, choice)
                        runBlocking(Dispatchers.Main) { CustomIcons.changed(); IconLibrary.changed() }
                    }
                    json(state().put("saved", ok))
                }
                session.method == Method.POST && path == "/api/icon/reset" -> {
                    val pkg = form(session)["app"].orEmpty()
                    if (installed(pkg)) { CustomIcons.clear(pkg); onMain { CustomIcons.changed() } }
                    json(state())
                }
                session.method == Method.POST && path == "/api/weather/city" -> {
                    val name = form(session)["name"].orEmpty()
                    val found = name.isNotBlank() && runBlocking(Dispatchers.Main) { Weather.choose(name) }
                    json(state().put("found", found))
                }
                session.method == Method.POST && path == "/api/weather/auto" -> {
                    onMain { Weather.useNetworkLocation() }
                    json(state())
                }
                // The file transfer page: a browser on the phone sends APKs and every other file
                // straight to this TV. Kept beside the wallpaper page, under the same random address.
                path == "/files" || path == "/files/" -> newFixedLengthResponse(
                    Response.Status.OK, "text/html; charset=utf-8", filesPage(),
                )
                session.method == Method.GET && path == "/api/files" -> json(filesState())
                session.method == Method.POST && path == "/api/files/send" -> receiveFile(session)
                session.method == Method.POST && path == "/api/files/install" -> installFile(form(session)["id"])
                session.method == Method.POST && path == "/api/files/open" -> openFile(form(session)["id"])
                session.method == Method.POST && path == "/api/files/delete" -> {
                    val removed = transferFile(form(session)["id"])?.delete() ?: false
                    json(filesState().put("removed", removed))
                }
                else -> text(Response.Status.NOT_FOUND, "Not found")
            }
        }.getOrElse {
            Log.w(TAG, "request failed", it)
            text(Response.Status.INTERNAL_ERROR, "error")
        }
    }

    private fun page(): String = context.assets.open("web/index.html").bufferedReader().use { it.readText() }
        .replace("{{DEVICE}}", Build.MODEL.replace("_", " "))

    /** The file transfer page, on the same random address as the setup page. */
    private fun filesPage(): String = context.assets.open("web/files.html").bufferedReader().use { it.readText() }
        .replace("{{DEVICE}}", Build.MODEL.replace("_", " "))

    /** Where files sent from the phone are kept: app-specific external storage, or internal if that is not there. */
    private fun transferDir(): File {
        val dir = context.getExternalFilesDir("transfer") ?: File(context.filesDir, "transfer")
        dir.mkdirs()
        return dir
    }

    private fun filesState(): JSONObject = JSONObject().put("files", JSONArray().apply {
        transferDir().listFiles { f -> f.isFile }?.sortedByDescending { it.lastModified() }?.forEach { f ->
            put(
                JSONObject().put("id", f.name).put("name", f.name).put("size", f.length())
                    .put("time", f.lastModified()).put("apk", f.extension.equals("apk", true)),
            )
        }
    }).put("room", transferDir().usableSpace)

    /** A file name from the phone, without any path: the browser sends only a base name, but a stray one must not escape. */
    private fun safeName(raw: String): String {
        val base = raw.substringAfterLast('/').substringAfterLast('\\').trim()
        val clean = buildString {
            for (c in base) append(if (c.code < 32 || c in "\\/:*?\"<>|") '_' else c)
        }.trim(' ', '.').ifEmpty { "file" }
        if (clean.length <= 160) return clean
        val dot = clean.lastIndexOf('.')
        return if (dot > 0) clean.substring(0, 150) + clean.substring(dot) else clean.substring(0, 160)
    }

    private fun uniqueFile(dir: File, name: String): File {
        var file = File(dir, name)
        if (!file.exists()) return file
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val extension = if (dot > 0) name.substring(dot) else ""
        var n = 2
        while (file.exists()) file = File(dir, "$stem ($n)$extension").also { n++ }
        return file
    }

    private fun transferFile(id: String?): File? {
        if (id.isNullOrEmpty()) return null
        val name = safeName(id)
        return File(transferDir(), name).takeIf { it.isFile }
    }

    /** Copy the request body to a file; the browser sends the bytes, not a multipart form, so a 1 GB APK never sits in memory. */
    private fun receiveFile(session: IHTTPSession): Response {
        val length = session.headers["content-length"]?.toLongOrNull() ?: -1L
        // No length means chunked or a truncated request: refuse it and close, so the rest of the
        // body is not read as the next request.
        if (length <= 0) return text(Response.Status.BAD_REQUEST, "length required").also { r -> r.closeConnection(true) }
        if (length > MAX_FILE) return text(Response.Status.BAD_REQUEST, "too large").also { r -> r.closeConnection(true) }
        val dir = transferDir()
        val room = dir.usableSpace
        // A few firmwares report 0 for a directory whose free space they cannot read; do not block
        // every transfer there, only when the number is real and too small.
        if (room > 0 && length > room - MIN_FREE) return text(Response.Status.BAD_REQUEST, "no room").also { r -> r.closeConnection(true) }
        val name = safeName(session.parameters["name"]?.firstOrNull().orEmpty())
        val target = uniqueFile(dir, name)
        var written = 0L
        // The session's input stream is the socket itself: closing it (as .use would) closes the
        // connection before NanoHTTPD can write the reply, and the phone reports a failed upload
        // even though the file arrived. Only the file's own stream is closed here.
        val input = session.inputStream
        try {
            target.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                while (written < length) {
                    val read = input.read(buffer, 0, minOf(buffer.size.toLong(), length - written).toInt())
                    if (read < 0) break
                    output.write(buffer, 0, read)
                    written += read
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "file transfer failed", e)
            target.delete()
            return text(Response.Status.BAD_REQUEST, "write failed").also { r -> r.closeConnection(true) }
        }
        if (written != length) {
            target.delete()
            return text(Response.Status.BAD_REQUEST, "incomplete").also { r -> r.closeConnection(true) }
        }
        return json(filesState().put("saved", true).put("id", target.name))
    }

    private fun installFile(id: String?): Response {
        val file = transferFile(id) ?: return text(Response.Status.NOT_FOUND, "file not found")
        if (!file.extension.equals("apk", true)) return text(Response.Status.BAD_REQUEST, "not an apk")
        val info = runCatching { context.packageManager.getPackageArchiveInfo(file.path, 0) }.getOrNull()
            ?: return text(Response.Status.BAD_REQUEST, "not a valid apk")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        val mime = "application/vnd.android.package-archive"
        val install = Intent(Intent.ACTION_INSTALL_PACKAGE).setDataAndType(uri, mime).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK,
        )
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK,
        )
        return runCatching { context.startActivity(install) }
            .recoverCatching { context.startActivity(view) }
            .fold(
                onSuccess = {
                    json(JSONObject().put("started", true).put("package", info.packageName).put("version", info.versionName ?: ""))
                },
                onFailure = {
                    Log.w(TAG, "no installer for the transferred apk", it)
                    text(Response.Status.INTERNAL_ERROR, "installer unavailable")
                },
            )
    }

    private fun openFile(id: String?): Response {
        val file = transferFile(id) ?: return text(Response.Status.NOT_FOUND, "file not found")
        if (file.extension.equals("apk", true)) return installFile(id)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        val open = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK,
        )
        return runCatching { context.startActivity(open) }
            .fold(
                onSuccess = { json(JSONObject().put("opened", true)) },
                onFailure = {
                    Log.w(TAG, "no app opens the transferred file", it)
                    text(Response.Status.INTERNAL_ERROR, "no app opens this file")
                },
            )
    }

    private fun state(): JSONObject {
        val list = JSONArray()
        val selected = Wallpapers.selectedId
        Wallpapers.items.forEach { w ->
            list.put(JSONObject().put("id", w.id).put("kind", w.kind.name.lowercase()).put("title", w.title).put("caption", w.caption ?: ""))
        }
        return JSONObject()
            .put("selected", selected)
            .put("latestDaily", Wallpapers.LATEST_DAILY)
            .put("rotatePhotos", Wallpapers.ROTATE_PHOTOS)
            .put("screensaver", Wallpapers.screensaver.key)
            .put("screensaverFollows", Wallpapers.screensaverFollows)
            .put("videos", JSONArray().apply {
                ScreensaverVideos.all(context).forEach { put(JSONObject().put("id", it.id).put("name", it.name)) }
            })
            .put("videoRoom", ScreensaverVideos.room(context))
            .put("focusStyle", AerialSettings.focusStyle.key)
            .put("kids", kidsState())
            .put("wallpaperAlwaysMoves", AerialSettings.wallpaperAlwaysMoves)
            .put("showWeather", AerialSettings.showWeather)
            .put("screensaverClock", AerialSettings.screensaverClock)
            .put("screensaverCaption", AerialSettings.screensaverCaption)
            .put("wallpapers", list)
            .put("apps", JSONArray().apply {
                // Pinned inputs first, then apps by the name Home shows. [default] is the name a
                // blank one goes back to; [name] is the one typed on this page, if any.
                val apps = AppCatalog.loaded.map { it to (AppNames.of(it.key) ?: it.label) }.sortedBy { it.second }
                AppCatalog.pinnedSources.forEach { a ->
                    val src = a.source ?: return@forEach
                    // An input's label as Home will show it once it has arranged the new look.
                    val look = SourceLooks.of(src.id)
                    val label = look?.let { it.name ?: it.device?.let { d -> context.getString(d.label) } } ?: src.label
                    // The stamp makes the phone fetch the tile again once its picture changes.
                    put(JSONObject().put("key", a.key).put("label", label).put("default", src.label).put("custom", CustomIcons.has(a.key)).put("stamp", CustomIcons.stamp(a.key))
                        .put("source", true).put("port", src.label).put("name", look?.name ?: "").put("device", look?.device?.key ?: "").put("look", look.hashCode()))
                }
                apps.forEach { (a, label) ->
                    // [icon] is where the tile's picture comes from now; [library] whether the icon
                    // library has one for this app, which the phone can pick instead.
                    val icon = when {
                        CustomIcons.has(a.key) -> "custom"
                        IconLibrary.has(a.key) && AppCatalog.usesLibrary(a.key) -> "library"
                        else -> "own"
                    }
                    put(JSONObject().put("key", a.key).put("label", label).put("default", a.label).put("name", AppNames.of(a.key) ?: "")
                        .put("custom", CustomIcons.has(a.key)).put("library", IconLibrary.has(a.key)).put("icon", icon)
                        .put("choices", libraryChoices(a.key, icon == "library"))
                        .put("stamp", CustomIcons.stamp(a.key) + IconLibrary.stamp(a.key) + icon.hashCode()))
                }
            })
            .put("layout", layoutState())
            .put("devices", JSONArray().apply { SourceDevice.entries.forEach { put(JSONObject().put("key", it.key).put("label", context.getString(it.label))) } })
            .put("inputs", JSONArray().apply {
                // Every input Home knows of, for pinning to Home from the phone.
                AppCatalog.sources.forEach { src ->
                    val look = SourceLooks.of(src.id)
                    put(JSONObject().put("id", src.id).put("port", src.label).put("device", src.deviceName ?: "")
                        .put("name", look?.let { it.name ?: it.device?.let { d -> context.getString(d.label) } } ?: "")
                        .put("pinned", src.id in AerialSettings.pinnedSources))
                }
            })
            .put("folders", JSONArray().apply {
                AppCatalog.folders.forEach { e ->
                    val f = e.folder ?: return@forEach
                    put(JSONObject().put("id", f.id).put("key", e.key).put("name", f.name).put("count", f.apps.size).put("stamp", e.art.hashCode()))
                }
            })
            .put("weather", JSONObject().apply {
                put("place", Weather.place ?: "")
                put("chosen", Weather.chosen)
                Weather.now?.let { put("celsius", it.celsius); put("kind", it.kind.name.lowercase()); put("day", it.day) }
            })
    }

    /** Home in order, each folder's apps and the hidden apps, by the names Home shows. */
    private fun layoutState(): JSONObject {
        fun tile(e: AppEntry) = JSONObject().put("key", e.key).put("label", e.label)
            .put("kind", when { e.folder != null -> "folder"; e.source != null -> "source"; else -> "app" })
            // Folder and input art changes without a picture from the phone (contents, chosen
            // device), an app's with the icon library too.
            .put("stamp", if (e.folder != null || e.source != null) e.art.hashCode().toLong() else CustomIcons.stamp(e.key) + IconLibrary.stamp(e.key))
            .apply { e.folder?.let { put("id", it.id) }; e.source?.let { put("port", it.label) } }
        val folders = JSONObject()
        AppCatalog.folderApps.forEach { (id, apps) -> folders.put(id, JSONArray().apply { apps.forEach { put(tile(it)) } }) }
        // With the parental PIN on, hidden apps stay hidden from here: on the TV, seeing them takes the PIN.
        val locked = AerialSettings.locked
        return JSONObject()
            .put("home", JSONArray().apply { AppCatalog.home.forEach { put(tile(it)) } })
            .put("folders", folders)
            .put("hidden", JSONArray().apply { if (!locked) AppCatalog.hiddenApps.forEach { put(tile(it)) } })
            .put("hiddenCount", AppCatalog.hiddenApps.size)
            .put("columns", AerialSettings.homeColumns)
            .put("locked", locked)
            .put("ready", AppCatalog.layout != null)
    }

    /**
     * One step of arranging Home from the phone: [op] is move, movein, hide, unhide, folder (into
     * [folder], or a new one when it is empty), unfolder or ungroup. Done on the main thread before
     * answering, so the state sent back shows it.
     */
    private fun layout(f: Map<String, String>): Response {
        val ops = AppCatalog.layout ?: return json(state().put("saved", false))
        val key = f["key"].orEmpty()
        val target = f["target"].orEmpty()
        val folder = f["folder"].orEmpty()
        val known = (AppCatalog.home + AppCatalog.folderApps.values.flatten() + AppCatalog.hiddenApps).map { it.key }.toSet()
        val step: (() -> Unit)? = when (f["op"]) {
            "move" -> if (key in known && target in known) ({ ops.move(key, target) }) else null
            "movein" -> if (key in known && target in known) ({ ops.moveInFolder(key, target) }) else null
            "hide" -> if (key in known) ({ ops.hide(key) }) else null
            "unhide" -> if (key in known && !AerialSettings.locked) ({ ops.unhide(key) }) else null
            "folder" -> if (key in known && !key.startsWith(FOLDER_KEY_PREFIX)) ({ ops.toFolder(key, folder.ifEmpty { null }) }) else null
            "unfolder" -> if (key in known) ({ ops.outOfFolder(key) }) else null
            "ungroup" -> if (folder in AppCatalog.folderApps) ({ ops.ungroup(folder) }) else null
            else -> null
        }
        if (step != null) runBlocking(Dispatchers.Main) { step() }
        return json(state().put("saved", step != null))
    }

    /** An app on the TV or a pinned input: the only tiles a picture may be sent for. */
    /** An app, a firmware shortcut such as Xiaomi's children's mode (issue #530), or a pinned input. */
    private fun installed(pkg: String) =
        pkg.isNotEmpty() && (AppCatalog.loaded.any { it.key == pkg } || AppCatalog.pinnedSources.any { it.key == pkg })

    /** The tile as Home shows it; with [own], as the app's own art would draw it. */
    private fun tile(pkg: String, own: Boolean = false): Response {
        val app = (AppCatalog.pinnedSources + AppCatalog.loaded + AppCatalog.folders).firstOrNull { it.key == pkg } ?: return text(Response.Status.NOT_FOUND, "")
        // An upload or a pick replies before Home's asynchronous reload has finished. Draw from the
        // saved picture or the pick directly, so the phone cannot cache the old tile under the new
        // versioned URL (a library pick showed the previous picture until the next change).
        val isApp = app.source == null && app.folder == null
        val library = isApp && !own && IconLibrary.has(pkg)
        val picked = when {
            own || !isApp -> null
            else -> CustomIcons.load(pkg) ?: if (library && AppCatalog.usesLibrary(pkg)) IconLibrary.load(pkg) else null
        }
        val bmp = picked ?: run {
            // The app's own art when asked for, or when the library has a picture it does not use.
            val art = if (isApp && (own || library)) AppCatalog.ownArt(context, app) ?: app.art else app.art
            TileArtFactory.flatten(art)
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        bmp.recycle()
        val bytes = out.toByteArray()
        return newFixedLengthResponse(Response.Status.OK, "image/jpeg", ByteArrayInputStream(bytes), bytes.size.toLong()).apply {
            addHeader("Cache-Control", "no-store")
        }
    }

    /**
     * The icon library's pictures of an app on this TV, the default first: [id], [by] (the source's
     * names: "name" and a name per language) and [on] for the one its tile uses ([inUse]: the tile
     * uses the library at all).
     */
    private fun libraryChoices(pkg: String, inUse: Boolean) = JSONArray().apply {
        val on = IconLibrary.chosen(pkg)?.id
        IconLibrary.choices(pkg).forEach { c ->
            put(JSONObject().put("id", c.id).put("by", IconLibrary.credits.optJSONObject(c.by) ?: JSONObject())
                .put("on", inUse && c.id == on))
        }
    }

    /** The icon library's picture of an app, as downloaded: [choice]'s, or the one its tile uses. */
    private fun libraryPicture(pkg: String, choice: String?): Response {
        val f = IconLibrary.file(pkg, choice) ?: return text(Response.Status.NOT_FOUND, "")
        val type = if (f.name.endsWith(".png")) "image/png" else "image/jpeg"
        return newFixedLengthResponse(Response.Status.OK, type, f.inputStream(), f.length()).apply {
            addHeader("Cache-Control", "max-age=600")
        }
    }

    private fun icon(session: IHTTPSession): Response {
        if (tooLarge(session)) return text(Response.Status.BAD_REQUEST, "too large")
        val files = HashMap<String, String>()
        session.parseBody(files)
        val pkg = session.parameters["app"]?.firstOrNull().orEmpty()
        if (!installed(pkg)) return text(Response.Status.BAD_REQUEST, "unknown app")
        val f = files.values.map(::File).firstOrNull { it.exists() && it.length() > 0 }
            ?: return text(Response.Status.BAD_REQUEST, "no picture")
        val saved = f.inputStream().use { CustomIcons.save(pkg, it, context.cacheDir) }
        if (saved) onMain { CustomIcons.changed() }
        return json(state().put("saved", saved))
    }

    private fun thumb(id: String): Response {
        val bmp = Wallpapers.thumbnail(java.net.URLDecoder.decode(id, "UTF-8")) ?: return text(Response.Status.NOT_FOUND, "")
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
        val bytes = out.toByteArray()
        return newFixedLengthResponse(Response.Status.OK, "image/jpeg", ByteArrayInputStream(bytes), bytes.size.toLong()).apply {
            addHeader("Cache-Control", "max-age=600")
        }
    }

    private fun upload(session: IHTTPSession): Response {
        if (tooLarge(session)) return text(Response.Status.BAD_REQUEST, "too large")
        val files = HashMap<String, String>()
        session.parseBody(files)
        var added = 0
        // NanoHTTPD stores each part in a temp file; several photos arrive as photo, photo1, photo2...
        files.values.forEach { path ->
            val f = File(path)
            if (f.exists() && f.length() > 0) {
                val id = f.inputStream().use { input -> runBlocking(Dispatchers.Main) { Wallpapers.addPhoto(input) } }
                if (id != null) added++
            }
        }
        return json(state().put("added", added))
    }

    /**
     * One film per request, its bytes as the body and its name in the address. Not through
     * [IHTTPSession.parseBody]: that writes the body to the cache, copies the file part out again and
     * maps the whole body into memory, which a 2 GB film on a 32-bit TV cannot afford (#1164).
     */
    private fun video(session: IHTTPSession): Response {
        val length = session.headers["content-length"]?.toLongOrNull() ?: 0L
        val name = session.parameters["name"]?.firstOrNull().orEmpty()
        val saved = ScreensaverVideos.receive(context, session.inputStream, length, name) != null
        if (saved) onMain { Wallpapers.videosChanged() }
        // A refused or broken film leaves unread bytes behind; do not read them as the next request.
        return json(state().put("saved", saved)).apply { if (!saved) closeConnection(true) }
    }

    // NanoHTTPD writes the whole body to the cache before we see it; keep a stray or hostile
    // upload from filling the TV's storage (#57).
    private fun tooLarge(session: IHTTPSession): Boolean =
        (session.headers["content-length"]?.toLongOrNull() ?: 0L) > MAX_UPLOAD

    private fun form(session: IHTTPSession): Map<String, String> {
        session.parseBody(HashMap())
        return session.parameters.mapValues { it.value.firstOrNull().orEmpty() }
    }

    private fun onMain(block: () -> Unit) = runBlocking(Dispatchers.Main) { block() }

    /**
     * The parental PIN, from the phone. Five wrong in a row and none is taken for a minute, so that
     * the 10 000 four-digit PINs cannot be tried from a phone in a few minutes.
     */
    private fun pinOk(pin: String?): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (pin.isNullOrEmpty() || now < pinRestUntil) return false
        if (AerialSettings.pinMatches(pin)) { pinMisses = 0; return true }
        if (++pinMisses >= 5) { pinMisses = 0; pinRestUntil = now + 60_000L }
        return false
    }
    @Volatile private var pinMisses = 0
    @Volatile private var pinRestUntil = 0L

    /** Kids and Elders mode as the page shows it: on or not, the day's time, a lock. */
    private fun kidsState(): JSONObject {
        val r = Restricted
        val now = System.currentTimeMillis()
        return JSONObject()
            .put("enabled", r.enabled)
            .put("active", r.active)
            .put("kind", r.kind.key)
            .put("pinSet", AerialSettings.pinSet)
            .put("pinArrows", AerialSettings.pinArrows)
            .put("usedMin", r.usage.usedMs / 60_000L)
            .put("limitMin", r.limitToday(now))
            .put("allowUntil", r.usage.allowUntil.takeIf { it > now } ?: 0L)
            .put("lock", when (r.lock) { is KidsLock.Break -> "break"; KidsLock.DayUsed -> "day"; KidsLock.Late -> "late"; null -> "" })
            .put("startMinute", r.rules.startMinute)
            .put("endMinute", r.rules.endMinute)
            // The whole setup, for the page's editor; changing it takes the PIN.
            .put("blockOthers", r.blockOthers)
            .put("guard", HomeGuardService.isRunning)
            .put("weekdayMinutes", r.rules.weekdayMinutes)
            .put("weekendMinutes", r.rules.weekendMinutes)
            .put("breakEvery", r.rules.breakEvery)
            .put("breakMinutes", r.rules.breakMinutes)
            .put("allowed", JSONArray(r.allowed))
            .put("candidates", JSONArray().apply {
                AppCatalog.kidsCandidates.forEach { e ->
                    put(JSONObject().put("key", e.key).put("label", e.label).put("source", e.source != null))
                }
            })
    }

    /**
     * The mode set up from the phone, all at once: who it is for, other apps, any number of
     * minutes, any window, the break, the tiles in order (keys one per line) and on or off.
     * Turned on here it starts at once: the parent is not at the TV. Nothing is kept unless all
     * of it is valid.
     */
    private fun kidsConfig(f: Map<String, String>): Response {
        fun int(key: String, default: Int) = f[key]?.trim()?.toIntOrNull() ?: default
        val current = Restricted.rules
        val rules = RestrictedRules(
            weekdayMinutes = int("weekday", current.weekdayMinutes),
            weekendMinutes = int("weekend", current.weekendMinutes),
            startMinute = int("start", current.startMinute),
            endMinute = int("end", current.endMinute),
            breakEvery = int("breakEvery", current.breakEvery),
            breakMinutes = int("breakMinutes", current.breakMinutes),
        )
        val known = AppCatalog.kidsCandidates.mapTo(HashSet()) { it.key }
        val allowed = f["allowed"]?.split('\n')?.map { it.trim() }?.filter { it in known }?.distinct() ?: Restricted.allowed
        val on = f["enabled"]?.let { it == "1" } ?: Restricted.enabled
        val kind = f["kind"]?.let { RestrictedKind.of(it) } ?: Restricted.kind
        if (!rules.valid || (on && allowed.isEmpty())) return json(state().put("saved", false))
        onMain {
            Restricted.chooseKind(kind)
            f["block"]?.let { Restricted.chooseBlockOthers(it == "1") }
            Restricted.chooseRules(rules)
            Restricted.chooseAllowed(allowed)
            if (on != Restricted.enabled) {
                Restricted.chooseEnabled(on)
                if (on) Restricted.start()
            }
            KidsWatch.poke()
        }
        return json(state().put("saved", true))
    }

    private fun json(o: JSONObject) = newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", o.toString())

    private fun text(status: Response.Status, msg: String) = newFixedLengthResponse(status, "text/plain; charset=utf-8", msg)

    companion object {
        const val PORT = 8790
        private const val TAG = "AerialPhone"
        /** Enough for a batch of phone photos at full size. */
        private const val MAX_UPLOAD = 200L * 1024 * 1024
        /** A transferred APK or film. Larger than any TV app, small enough not to fill a 32 GB stick. */
        private const val MAX_FILE = 1024L * 1024 * 1024
        /** Keep this much room after a transfer, so the TV can still write its caches and updates. */
        private const val MIN_FREE = 64L * 1024 * 1024
        /** As for an input's name: Home's caption has room for about this much. */
        private const val FOLDER_NAME_MAX = 24

        @Volatile
        private var running: PhoneServer? = null

        /**
         * Listens for as long as Aerial runs, from Home's start (MainActivity.startWork), so a
         * computer can open the page at any time without Personalize open on the TV. On every
         * interface: the address the TV has may change, the page stays the same.
         */
        @Synchronized
        fun listen(context: Context): PhoneServer? {
            running?.let { if (it.isAlive) return it }
            return runCatching {
                PhoneServer(context.applicationContext, token(context)).also {
                    it.start(SOCKET_READ_TIMEOUT, true)
                    running = it
                }
            }.onFailure { Log.w(TAG, "could not listen", it) }.getOrNull()
        }

        /** The address to put in the QR code, listening first if need be, or null offline. */
        fun start(context: Context): String? {
            val ip = lanAddress(context) ?: return null
            val server = listen(context) ?: return null
            return "http://$ip:$PORT/${server.token}/"
        }

        /** The address of the file transfer page: the same server, its own page under the same random token. */
        fun filesUrl(context: Context): String? = start(context)?.let { it + "files/" }

        /**
         * Kept from one start to the next, so the address can be bookmarked on a computer and the
         * phone's tab still works the next day.
         */
        private fun token(context: Context): String {
            val prefs = context.getSharedPreferences("phone_page", Context.MODE_PRIVATE)
            prefs.getString("token", null)?.takeIf { it.length == 8 }?.let { return it }
            return newToken().also { prefs.edit().putString("token", it).apply() }
        }

        private fun newToken(): String {
            val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
            val rnd = SecureRandom()
            return (1..8).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
        }

        fun lanAddress(context: Context): String? {
            val cm = context.getSystemService<ConnectivityManager>() ?: return null
            val current = cm.currentNetwork()
            // Under a proxy app's VPN the default network is the tunnel, whose address the phone
            // cannot reach (Clash and the like use 198.18.0.1; Xiaomi S55, issue #667). The Wi-Fi
            // or Ethernet network under it is still in allNetworks: take its address first.
            val networks = runCatching { cm.allNetworks.toList() }.getOrDefault(emptyList())
            val lan = networks.filter { n ->
                val caps = runCatching { cm.getNetworkCapabilities(n) }.getOrNull() ?: return@filter false
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
                    (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
            }.sortedByDescending { it == current }
            return (lan + listOfNotNull(current)).firstNotNullOfOrNull { n ->
                runCatching { cm.getLinkProperties(n) }.getOrNull()?.linkAddresses?.map { it.address }
                    ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress && !it.isLinkLocalAddress && !isBenchmark(it) }
            }?.hostAddress
        }

        /** 198.18.0.0/15, the range proxy apps put their tunnel in; never a home network. */
        private fun isBenchmark(address: java.net.InetAddress): Boolean {
            val b = address.address
            return b.size == 4 && (b[0].toInt() and 0xff) == 198 && (b[1].toInt() and 0xfe) == 18
        }

        /** A QR code, dark modules on white, each module [scale] pixels square. */
        fun qr(text: String, scale: Int = 8): Bitmap {
            val matrix = QRCodeWriter().encode(
                text, BarcodeFormat.QR_CODE, 0, 0,
                mapOf(EncodeHintType.MARGIN to 0, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M),
            )
            val n = matrix.width
            val bmp = createBitmap(n * scale, n * scale)
            for (y in 0 until n) for (x in 0 until n) {
                if (matrix[x, y]) for (dy in 0 until scale) for (dx in 0 until scale) bmp.setPixel(x * scale + dx, y * scale + dy, Color.BLACK)
                else for (dy in 0 until scale) for (dx in 0 until scale) bmp.setPixel(x * scale + dx, y * scale + dy, Color.WHITE)
            }
            return bmp
        }
    }
}
